64-bit windows builds of ICU libraries.

Note these are available as source under the X license
from 

  http://icu.sourceforge.net/




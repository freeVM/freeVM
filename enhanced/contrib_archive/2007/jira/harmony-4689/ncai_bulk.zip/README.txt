INTEL CONTRIBUTION TO APACHE HARMONY
          August 23, 2007
======================================

This archive contains the contribution to the Apache
Harmony project from Intel. The contribution consists
of the following functionality:

     - Native Code Access Interface implementation (NCAI)



1. ARCHIVE CONTENTS
-------------------

The archive contains a set of new files and the patch for existing
DRLVM files. New files are laid out with the current
DRLVM directory structure of the Apache Harmony SVN repository.
Before extracting the archive, check out Harmony DRLVM by following
the instructions at
http://harmony.apache.org/subcomponents/drlvm/index.html

The patch should be applied to root DRLVM directory.
  
                      
2. BUILDING 
------------

1. Add the contents of the 'vm' directory in the archive to the contents
of existing DRLVM 'vm' directory.

2. Apply provided patch from the top-level directory of DRLVM.

3. Build DRLVM as usual

       cd build
       ./build.sh


3. KNOWN ISSUES
---------------

One of the new files is vm/vmcore/src/ncai/README. This file contains
implementation notes for the provided implementation.


4. DISCLAIMER AND LEGAL INFORMATION
------------------------------------

*) Other brands and names are the property of their respective owners.

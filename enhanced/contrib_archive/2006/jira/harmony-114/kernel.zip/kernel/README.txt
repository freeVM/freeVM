Feb 21, 2006
Weldon Washburn, Intel


kernel_path is a generic adapter that will glue the
Apache Harmony Class Library to any Java Virtual Machine that
runs GNU Classpath.

The code in this tree is very new.  It compiles without error but has
not been executed.

The first JVM that kernel_path will run on is Harmony JCHEVM.  It 
is located at:

http://svn.apache.org/viewcvs.cgi/incubator/harmony/enhanced/jchevm/

The next phase of this project is to download JCHEVM and build it.  Then
overlay kernel_path on Harmony Class Library kernel directory and rebuild
the entire library.  Run hello_world.java on JCHEVM/kernel_path and start debugging.

Directions for obtaining a copy of Harmony Class Library are at:

http://incubator.apache.org/harmony/subcomponents/classlibrary/build_classlib.html

In the Harmony Class Library tree is a document describing how to connect the
libraries to a new Java Virtual Machine.  These directions are located in the tree at:

....../Harmony/doc/kernel/kernel.txt

kernel.txt states:

The Kernel Java classes are those classes which are tied to the structure 
of the VM, or whose structure is known by the VM. Most of these classes 
are defined by the Java 1.4.2 API specification. The IBM VM implementations 
of these classes are provided in open source. The IBM implementations 
rely on the presence of (typically) VM specific natives to implement the 
required Java APIs. Other VM writers can choose to use these implementations, 
but this forces the writer to use the reference design and the writer must 
then implement the natives, for which minimal documentation is provided.

kernel_path is a copy of the following Harmony Class Library sub-tree:

...../Harmony/modules/kernel

Current status of these files:

Files named VM*.java contain the java declaration of JCHEVM's native method
entry points.  These are java source files that correspond to _jc_ilib_table [ ]
that is defined in:

http://svn.apache.org/viewcvs.cgi/incubator/harmony/enhanced/jchevm/libjc/native_lib.c

Most of the mods were done to the kernel/src/main/java/java/lang directory.

The most complete files are:

Class.java
Object.java
String.java
Runtime.java
System.java
Thread.java

The least complete files are:

ClassLoader.java
Compiler.java
Package.java
StackTraceElement.java
ThreadGroup.java
Throwable.java

None of the following files have been modified yet:

kernel/src/main/java/java/lang/ref/*
kernel/src/main/java/java/lang/reflect/*
kernel/src/main/java/com/ibm/oti/vm/*






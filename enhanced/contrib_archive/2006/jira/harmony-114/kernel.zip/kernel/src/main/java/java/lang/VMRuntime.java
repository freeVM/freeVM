/* Copyright 1998, 2006 The Apache Software Foundation or its licensors, as applicable
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package java.lang;

public class VMRuntime 
{
    static public final native int availableProcessors();

    static public final native void exit(int code);

    static public final native long freeMemory();

    static public final native void gc();

    static public final native String mapLibraryName(String ss);

    static public final native long maxMemory();

    static public final native int nativeLoad(String ss, ClassLoader cl);

    static public final native void runFinalization();

    static public final native void runFinalizationForExit();

    static public final native void runFinalizersOnExit(boolean bb);

    static public final native long totalMemory();

    static public final native void traceInstructions(boolean bb);

    static public final native void traceMethodCalls(boolean bb);

}
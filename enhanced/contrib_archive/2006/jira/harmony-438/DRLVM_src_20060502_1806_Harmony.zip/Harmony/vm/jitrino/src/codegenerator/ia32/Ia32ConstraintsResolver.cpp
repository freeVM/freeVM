/*
 *  Copyright 2005-2006 The Apache Software Foundation or its licensors, as applicable.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 */
/**
 * @author Vyacheslav P. Shakin
 * @version $Revision: 1.11.14.2.4.3 $
 */

#include "Ia32ConstraintsResolver.h"

namespace Jitrino
{
namespace Ia32{

//========================================================================================
// class ConstraintsResolverImpl
//========================================================================================

/**
 *	class Ia32ConstraintsResolverImpl is implementation of simple constraint resolution algorithm
 *	The algorithm takes one-pass over CFG.
 *
 *	The algorithm works as follows:	
 *		
 *	1)	Creates an array of basic blocks and orders by bb->getExecCnt() 
 *		in createBasicBlockArray().
 *		Thus, the algorithm handles hottest basic blocks first and constraints are assigned to operands first 
 *		from the most frequently used instructions
 *
 *	2)	Collects a bit vector of all operands live at entries of all dispatch node entries
 *		in calculateLiveAtDispatchBlockEntries()
 *
 *	3)	For all operands:
 *		 c0) has already been assigned to some location (its location constraint is not null) 
 *		 c1) or has some Initial constraint with kind!=OpndKind_Any
 *		 c2) or is live at entry of a dispatch node 
 *		the calculated constraint is pre-set to these constraints
 *		This is done in calculateStartupOpndConstraints()
 *
 *	4)  Walks through all basic blocks collected and arranged at step 1
 *		in resolveConstraints()
 *
 *		The opndReplaceWorkset array of operand replacements is maintained 
 *		(indexed by from-operand id). 
 *
 *		This is the array of current replacement for operands
 *		and is reset for each basic block (local within basic blocks) 
 *
 *		This array is filled as a result of operand splitting and indicates
 *		which operand must be used instead of original ones for all the instructions
 *		above the one caused splitting
 *		
 *		4.1) Walks throw all instruction of a basic block in backward order 
 *			in resolveConstraints(BasicBlock * bb) 
 *			4.1.1) resolves constraints for each instruction 
 *				in resolveConstraints(Inst * inst);
 *			
 *				To do this already collected calculated constraint of 
 *				either original operand or its current replacement is anded 
 *				with instruction constraint for this operand occurence and
 *				if the result is null, new operand is created and substituted instead
 *								
 *				4.1.1.1) All def operands of the isntruction are traversed
 *					and operand splitting is performed after the instruction (when necessary)
 *					def&use cases are also handled during this step 
 *				4.1.1.2) If the instruction is CALL, all hovering operands of 
 *					the isntruction are traversed.
 *
 *					Hovering operands are operands which are live across a call site and are not
 *					redefined in the call site
 *					This step ensures operands are saved in callee-save regs or memory 
 *					and takes into account whether an operand is live at dispatch node entries
 *
 *					Operand splitting is performed before the instruction (when necessary)
 *				4.1.1.3) All use operands of the instruction are traversed
 *					and operand splitting is performed before the instruction (when necessary)
 *				
 *		For more details please refer to ConstraintsResolverImpl source code
 */

class ConstraintsResolverImpl
{
public:
	ConstraintsResolverImpl(IRManager &irm)
		:irManager(irm), 
		memoryManager(irManager.getOpndCount()*16, "ConstraintsResolverImpl"),
        basicBlocks(memoryManager, 0), originalOpndCount(0),
		liveOpnds(memoryManager,0),
		liveAtDispatchBlockEntry(memoryManager,0),
		needsOriginalOpnd(memoryManager,0),
		hoveringOpnds(memoryManager,0),
		opndReplaceWorkset(memoryManager,0)
	{
	}
	
	void run();

private:
    /** Get the priority of a the node for sorting in createBasicBlockArray */
    ExecCntValue getBasicBlockPriority(Node * node);
    /** Fills the basicBlocks array and orders it according to block exec count (hottest first) */ 
	void createBasicBlockArray();
	/** Fills the liveAtDispatchBlockEntry bit set with operands live at dispatch node entries */ 
	void calculateLiveAtDispatchBlockEntries();
	/** Pre-sets calculated constraints for each operand if conditions c0-c2 are met */ 
	void calculateStartupOpndConstraints();
	/** Scans basicBlocks array and calls resolveConstraints(BasicBlock * bb) for each entry */
	void resolveConstraints();
	/** Traverses instructions of bb and calls resolveConstraints(Inst *) 
	 * for each inst 
	 */
	void resolveConstraints(BasicBlock * bb);
	/**
	 Main logic of constraint resolution for each instrution
	 */
	void resolveConstraints(Inst * inst);

	/** returns constraint describing call-safe locations for opnd in CallInst inst */
	Constraint getCalleeSaveConstraint(Inst * inst, Opnd * opnd);
	/** returns constraint describing safe locations for operands live at dispatch node entries */
	Constraint getDispatchEntryConstraint(Opnd * opnd);


	/** Reference to IRManager */ 
	IRManager&					irManager;

	/** Private memory manager for this algorithm */ 
	MemoryManager				memoryManager;

	/** Array of basic blocks to be handled */ 
	StlVector<BasicBlock *>		basicBlocks;

	/** result of irManager.getOpndCount before the pass */ 
	uint32						originalOpndCount;

	/** Current live set, updated as usual for each instruction in resolveConstraints(Inst*) */ 
	LiveSet						liveOpnds;

	/** Bit set of operands live at dispatch node entries */ 
	BitSet						liveAtDispatchBlockEntry;

	/** Bit set of operands met conditions c0-c2 described above */ 
	BitSet						needsOriginalOpnd;

	/** Temporary bit set of hovering operands (live across call sites)
	 *  Is initialized and used only during resolveConstraints(Inst*)
	 */ 
	BitSet						hoveringOpnds;

	/** An array of current substitutions for operands
	 *	Is filled as a result of operand splitting.
	 *  Reset for each basic blocks (all replacements are local within basic blocks)
	 */
	StlVector<Opnd*>			opndReplaceWorkset;
};

//_________________________________________________________________________________________________
Constraint ConstraintsResolverImpl::getCalleeSaveConstraint(Inst * inst, Opnd * opnd)
{
// This implementation don't take into account operand types 
// and provides only GP call-safe regs (thus only memory for non-integer and non-pointer types)
	Constraint c=(Constraint(OpndKind_Memory)|RegName_EDI|RegName_ESI|RegName_EBX|RegName_EBP|RegName_ESP) & 
		opnd->getConstraint(Opnd::ConstraintKind_Initial);
	return c.isNull()?Constraint(OpndKind_Memory, opnd->getSize()):c;
}

//_________________________________________________________________________________________________
Constraint ConstraintsResolverImpl::getDispatchEntryConstraint(Opnd * opnd)
{
// Currently the same result as from getCalleeSaveConstraint
	Constraint c=(Constraint(OpndKind_Memory)|RegName_EDI|RegName_ESI|RegName_EBX|RegName_EBP|RegName_ESP) & 
		opnd->getConstraint(Opnd::ConstraintKind_Initial);
	return c.isNull()?Constraint(OpndKind_Memory, opnd->getSize()):c;
}

//_________________________________________________________________________________________________
void ConstraintsResolverImpl::run()
{
//  Set all instruction constraints for EntryPoints, CALLs and RETs
	irManager.applyCallingConventions();
// Initialization 
	originalOpndCount=irManager.getOpndCount();
	liveOpnds.resizeClear(originalOpndCount);
	needsOriginalOpnd.resizeClear(originalOpndCount);
	liveAtDispatchBlockEntry.resizeClear(originalOpndCount);

	opndReplaceWorkset.resize(originalOpndCount);
	for (uint32 i=0; i<originalOpndCount; i++)
		opndReplaceWorkset[i]=NULL;

	hoveringOpnds.resize(originalOpndCount);
// Fill array of basic blocks and order it
	createBasicBlockArray();
// Collect operands live at dispatch blocks
	calculateLiveAtDispatchBlockEntries();
// Pre-set calculated constraints for operands satisfying c0-c2 
	calculateStartupOpndConstraints();
// Resolve constraints
	resolveConstraints();
// This is a local transformation, resize liveness vectors
	irManager.fixLivenessInfo();
}

//_________________________________________________________________________________________________

ExecCntValue ConstraintsResolverImpl::getBasicBlockPriority(Node * node)
{ 
// Use simple heuristics to handle prologs and epilogs after all other nodes.
// This improves performance as prologs and epilogs usually set bad constraints
// to operands (entry points, rets)
    return  
        irManager.getPrologNode() == node ? (ExecCntValue)0 : 
        irManager.isEpilog(node) ? (ExecCntValue)1 : 
        (ExecCntValue)10 + node->getExecCnt();
}


//_________________________________________________________________________________________________
void ConstraintsResolverImpl::createBasicBlockArray()
{
    // Filling of basicBlock, simple insertion-based ordering of basic blocks
    for (CFG::NodeIterator it(irManager); it!=NULL; ++it){
        if (((Node*)it)->hasKind(Node::Kind_BasicBlock)){
            BasicBlock * bb = (BasicBlock*)(Node*)it;
            ExecCntValue bbecv = getBasicBlockPriority(bb);
            uint32 ibb=0;
            for (uint32 nbb=basicBlocks.size(); ibb<nbb; ++ibb){
                if (bbecv > getBasicBlockPriority(basicBlocks[ibb]))
                    break;
            }
            basicBlocks.insert(basicBlocks.begin()+ibb, bb);
        }
    }
}

//_________________________________________________________________________________________________
void ConstraintsResolverImpl::calculateLiveAtDispatchBlockEntries()
{	
	for (CFG::NodeIterator it(irManager); it!=NULL; ++it){
		Node * node=it;
		if (node->hasKind(Node::Kind_DispatchNode))
			liveAtDispatchBlockEntry.unionWith(*irManager.getLiveAtEntry(node));
	}
}	
	
//_________________________________________________________________________________________________
void ConstraintsResolverImpl::calculateStartupOpndConstraints()
{	
// Reset calculated constraints to null constraints
	irManager.resetOpndConstraints();
// For all operands in the CFG
	for (uint32 i=0; i<originalOpndCount; i++){ 
		Opnd * opnd=irManager.getOpnd(i);

		Constraint c=opnd->getConstraint(Opnd::ConstraintKind_Initial);
		Constraint cl=opnd->getConstraint(Opnd::ConstraintKind_Location);

		if (!cl.isNull()) // Condition c0 satisfied
			c=cl; 

		if (liveAtDispatchBlockEntry.getBit(i)){ // Condition c2 satisfied
			if (cl.isNull()){ // if location is set it is not changed over call sites potentially leading to dispatch/catch nodes
				c=c & getDispatchEntryConstraint(opnd);
			}
			needsOriginalOpnd.setBit(i);
		}
		// result must not be null as well as opnd initial constrains 
		assert(!c.isNull() && !opnd->getConstraint(Opnd::ConstraintKind_Initial).isNull());
		// set the results
		opnd->setCalculatedConstraint(c); 
	}
}	
	
//_________________________________________________________________________________________________
void ConstraintsResolverImpl::resolveConstraints(Inst * inst)
{	
	// Initialize hoveringOpnds with operands live after the call if the inst is CALL
	if (inst->getMnemonic()==Mnemonic_CALL)
		hoveringOpnds.copyFrom(liveOpnds);

	// first handle all defs
	{Inst::Opnds opnds(inst, Inst::OpndRole_AllDefs);
	for (Inst::Opnds::iterator it = opnds.begin(); it != opnds.end(); it = opnds.next(it)){
		Opnd * originalOpnd=inst->getOpnd(it);

		// We haven't changed def-operands yet for this instruction
		assert(originalOpnd->getId()<originalOpndCount);
		// We replace needsOriginalOpnd's operans (conditions c0-c2) only 
		// when the original operand don't satisfy instruction constraints 
		// and always keep the original one in other cases
		assert(!needsOriginalOpnd.getBit(originalOpnd->getId())||opndReplaceWorkset[originalOpnd->getId()]==NULL);
		// currentOpnd is either the current replacement or the original operand
		Opnd * currentOpnd=opndReplaceWorkset[originalOpnd->getId()];
		if (currentOpnd==NULL)
			currentOpnd=originalOpnd;
		// get what is already collected
		Constraint cc=currentOpnd->getConstraint(Opnd::ConstraintKind_Calculated);
		assert(!cc.isNull());
		// get the weak instruction constraint for this occurrence
		Constraint ci=inst->getConstraint(Inst::ConstraintKind_Weak, it, originalOpnd->getSize());
		assert(!ci.isNull());
		// & the result
		Constraint cr=cc & ci;
		Opnd * opndToSet=currentOpnd;
		if (!cr.isNull()){
			// can substitute currentReplacementOpnd into this position
			currentOpnd->setCalculatedConstraint(cr);
		}else{
			// cannot substitute currentReplacementOpnd into this position, needs splitting
			opndToSet=irManager.newOpnd( originalOpnd->getType(), ci | Constraint(OpndKind_Mem, ci.getSize()) );
			Inst * copySequence=irManager.newCopyPseudoInst(Mnemonic_MOV, currentOpnd, opndToSet);	
			// split after the defining instruction
			inst->getBasicBlock()->appendInsts(copySequence, inst);
			if (inst->getOpndRoles(it)&Inst::OpndRole_Use){
				// This is def&use case (like add t0, t1 for t0)
				if (!needsOriginalOpnd.getBit(originalOpnd->getId())){
					// c0-c2 are not satisfied, use the new operand for all the instructions above
					opndReplaceWorkset[originalOpnd->getId()]=opndToSet;
				}else{
					// c0-c2 are satisfied, use the original operand for all the instructions above
					assert(currentOpnd==originalOpnd);
					Inst * copySequence=irManager.newCopyPseudoInst(Mnemonic_MOV, opndToSet, originalOpnd);	
					// split above the instruction
					inst->getBasicBlock()->prependInsts(copySequence, inst);
				}
			}
		}	
		// Update liveness
		if (inst->isLiveRangeEnd(it)){ // if pure def, not def&use, terminate live range
			liveOpnds.setBit(originalOpnd->getId(), false);
			// also terminate replacement chain
			opndReplaceWorkset[originalOpnd->getId()] = NULL;
		}
		// need to set the new operand into this place of the instruction
		if (opndToSet!=originalOpnd)
			inst->setOpnd(it, opndToSet);

	}}

	// now handle operands hovering over call insts
	if (inst->getMnemonic()==Mnemonic_CALL){
		// for all operands 
		LiveSet::IterB ib(hoveringOpnds);
		for (int i = ib.getNext(); i != -1; i = ib.getNext()){
			Opnd * originalOpnd=irManager.getOpnd(i);
			// The same checks that we check c0-c2 properly
			assert(originalOpnd->getId()<originalOpndCount);
			assert(!needsOriginalOpnd.getBit(originalOpnd->getId())||opndReplaceWorkset[originalOpnd->getId()]==NULL);
			// currentOpnd is either the current replacement or the original operand
			Opnd * currentOpnd=opndReplaceWorkset[originalOpnd->getId()];
			if (currentOpnd==NULL)
				currentOpnd=originalOpnd;
			Opnd * opndToSet=NULL;
			// was live and is not redefined by this inst
			if (liveOpnds.isLive(originalOpnd)){ 
				// Instruction-level constraints are constraints describing locations safe across CALLs 
				Constraint ci=getCalleeSaveConstraint(inst, currentOpnd);
				// we have at least memory
				assert(!ci.isNull());
				Constraint cc=currentOpnd->getConstraint(Opnd::ConstraintKind_Calculated);
				assert(!cc.isNull());
				// & the result
				Constraint cr=cc & ci;
				opndToSet=currentOpnd;
				if (cr.getMask()!=0 || cc.getMask()==0){
					// can substitute currentReplacementOpnd into this position
					opndToSet->setCalculatedConstraint(cr);
				}else{
					// cannot substitute currentReplacementOpnd into this position, needs splitting
					// Try to use originalOpnd over this instruction and for the instructions above
				    Constraint co=originalOpnd->getConstraint(Opnd::ConstraintKind_Calculated);
					Constraint cr=co & ci;
					if (cr.getMask()!=0 || co.getMask()==0){ 
						opndToSet=originalOpnd;
						opndToSet->setCalculatedConstraint(cr);
					}else{
						// cannot use original, create a new one
						opndToSet=irManager.newOpnd(originalOpnd->getType(), ci | Constraint(OpndKind_Mem, ci.getSize()));
					}
				}	
			}

			if (opndToSet!=NULL){
				if (opndToSet!=currentOpnd){
					// an operand different to the current replacement 
					// is required to be over this call site, append splitting below the call site
					// this is like restoring from a call-safe location under a call
					Inst * copySequence=irManager.newCopyPseudoInst(Mnemonic_MOV, currentOpnd, opndToSet);	
					inst->getBasicBlock()->appendInsts(copySequence, inst);
				}
				// no c0-c2, can use the replacement operand above
				if (!needsOriginalOpnd.getBit(originalOpnd->getId()))
					opndReplaceWorkset[originalOpnd->getId()]=opndToSet;
				else if (opndToSet!=originalOpnd){
					// add splitting above 
					// this is like saving into a call-safe location above a call
					assert(currentOpnd==originalOpnd);
					Inst * copySequence=irManager.newCopyPseudoInst(Mnemonic_MOV, opndToSet, originalOpnd);
					inst->getBasicBlock()->prependInsts(copySequence, inst);
				}
			}
		}
	}
	
	// now handle all uses 
	{Inst::Opnds opnds(inst, Inst::OpndRole_AllUses);
	for (Inst::Opnds::iterator it = opnds.begin(); it != opnds.end(); it = opnds.next(it)){
		Opnd * originalOpnd=inst->getOpnd(it);
		
		if ((inst->getOpndRoles(it)&Inst::OpndRole_Def)==0){  // the use&def case was handled above
			// The same checks that we check c0-c2 properly
			assert(originalOpnd->getId()<originalOpndCount);
			assert(!needsOriginalOpnd.getBit(originalOpnd->getId())||opndReplaceWorkset[originalOpnd->getId()]==NULL);
			// currentOpnd is either the current replacement or the original operand
			Opnd * currentOpnd=opndReplaceWorkset[originalOpnd->getId()];
			if (currentOpnd==NULL)
				currentOpnd=originalOpnd;
			// get what is already collected
			Constraint cc=currentOpnd->getConstraint(Opnd::ConstraintKind_Calculated);
			assert(!cc.isNull());
		// get the weak instruction constraint for this occurrence
			Constraint ci=inst->getConstraint(Inst::ConstraintKind_Weak, it, originalOpnd->getSize());
			assert(!ci.isNull());
			Constraint cr=cc & ci;

			Opnd * opndToSet=currentOpnd;

			if (!cr.isNull()){
				// can substitute currentReplacementOpnd into this position
				currentOpnd->setCalculatedConstraint(cr);
			}else{
				// cannot substitute currentReplacementOpnd into this position, needs splitting
				// split above the inst, force to insert the new operand into the inst, and use
				// currentOpnd above
				opndToSet=irManager.newOpnd(originalOpnd->getType(), ci | Constraint(OpndKind_Mem, ci.getSize()));
				Inst * copySequence=irManager.newCopyPseudoInst(Mnemonic_MOV, opndToSet, currentOpnd);
				inst->getBasicBlock()->prependInsts(copySequence, inst);
			}	
			// update liveness (for def/use case
			if (inst->isLiveRangeStart(it))
				liveOpnds.setBit(originalOpnd->getId(), true);
			// need to set the new operand into this place of the instruction
			if (opndToSet!=originalOpnd)
				inst->setOpnd(it, opndToSet);
		}
	}}	
}	
	
//_________________________________________________________________________________________________
void ConstraintsResolverImpl::resolveConstraints(BasicBlock * bb)
{
	// scan all insts of bb in reverse order
	const Insts& insts=bb->getInsts();
	irManager.getLiveAtExit(bb, liveOpnds);
	for (Inst * inst=insts.getLast(), * prevInst=NULL; inst!=NULL; inst=prevInst){
		prevInst=insts.getPrev(inst);
		resolveConstraints(inst);
	}

	// if we come to bb entry with some replacement for an operand and the operand is live at the entry
	// insert copying from the original operand to the replacement operand
	LiveSet * ls = irManager.getLiveAtEntry(bb);
	LiveSet::IterB ib(*ls);
	for (int i = ib.getNext(); i != -1; i = ib.getNext()){
		Opnd * originalOpnd = irManager.getOpnd(i);
		assert(originalOpnd->getId()<originalOpndCount);
		Opnd * currentOpnd=opndReplaceWorkset[originalOpnd->getId()];
		if (currentOpnd!=NULL){
			if (currentOpnd!=originalOpnd){
//				assert(irManager.getLiveAtEntry(bb)->isLive(originalOpnd));
				Inst * copySequence=irManager.newCopyPseudoInst(Mnemonic_MOV, currentOpnd, originalOpnd);
				bb->prependInsts(copySequence);
			}
			opndReplaceWorkset[originalOpnd->getId()]=NULL;
		}
	}
}

//_________________________________________________________________________________________________
void ConstraintsResolverImpl::resolveConstraints()
{	
	// for all basic blocks in the array
	for (uint32 ibb=0, nbb=basicBlocks.size(); ibb<nbb; ++ibb){
		resolveConstraints(basicBlocks[ibb]);
	}
		
}	

//_________________________________________________________________________________________________
void ConstraintsResolver::runImpl()
{
	// call the private implementation of the algorithm
	ConstraintsResolverImpl(irManager).run();
}


//_________________________________________________________________________________________________



}}; //namespace Ia32


/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * 
 */

package java.lang.management;

import java.security.BasicPermission;

/**
 * This is the security permission that code running with a Java security
 * manager will be verified against when attempts are made to invoke methods in
 * the platform's management interface.
 * <p>
 * Instances of this type are normally created by security code.
 * </p>
 * 
 * @since 1.5
 */
public final class ManagementPermission extends BasicPermission {

    /**
     * Helps to determine if a de-serialized file is compatible with this type.
     */
    private static final long serialVersionUID = 1897496590799378737L;

    private static final String CONTROL = "control";
    private static final String MONITOR = "monitor"; 
    
    /**
     * Creates a new instance of <code>ManagementPermission</code> with 
     * the given name.
     * @param name the name of the permission. The only acceptable values
     * are the strings &quot;control&quot; or &quot;monitor&quot;.
     * @throws IllegalArgumentException if <code>name</code> is not one of 
     * the string values &quot;control&quot; or &quot;monitor&quot;.
     * @throws NullPointerException if <code>name</code> is <code>null</code>.
     */
    public ManagementPermission(String name) {
        this(name, null);
    }

    /**
     * Creates a new instance of <code>ManagementPermission</code> with 
     * the given name and permitted actions.
     * @param name the name of the permission. The only acceptable values
     * are the strings &quot;control&quot; or &quot;monitor&quot;.
     * @param actions this argument must either be an empty string or 
     * <code>null</code>.
     * @throws NullPointerException if <code>name</code> is <code>null</code>.
     */
    public ManagementPermission(String name, String actions) {
        super(name, actions);
        if (actions != null && actions.length() != 0) {
            throw new IllegalArgumentException(
                    "The actions argument must be either null or the empty string.");
        }
        if ((name == null) || (!CONTROL.equals(name) && !MONITOR.equals(name))) {
            throw new IllegalArgumentException(
                    "Only control or monitor values expected for ManagementPermission name.");
        }
    }
}


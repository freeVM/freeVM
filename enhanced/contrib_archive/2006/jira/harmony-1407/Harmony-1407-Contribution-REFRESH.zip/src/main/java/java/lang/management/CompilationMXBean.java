/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * 
 */

package java.lang.management;

/**
 * The management and monitoring interface for the virtual machine's compilation
 * functionality.
 * <p>
 * If the virtual machine has a compilation system enabled, precisely one
 * instance of this interface will be made available to management clients.
 * Otherwise, there will be no instances of this <code>MXBean</code> available.
 * </p>
 * <p>
 * Accessing this <code>MXBean</code> can be done in one of three ways. <br/>
 * <ol>
 * <li>Invoking the static ManagementFactory.getCompilationMXBean() method.
 * </li>
 * <li>Using a javax.management.MBeanServerConnection.</li>
 * <li>Obtaining a proxy MXBean from the static
 * {@link ManagementFactory#newPlatformMXBeanProxy}
 * method, passing in the string &quot;java.lang:type=Compilation&quot; for
 * the value of the second parameter.
 * </li>
 * </ol>
 * </p>
 * 
 */
public interface CompilationMXBean {

    /**
     * Returns the name of the virtual machine's Just In Time (JIT) compiler.
     * 
     * @return the name of the JIT compiler
     */
    public String getName();

    /**
     * If supported (see {@link #isCompilationTimeMonitoringSupported()}),
     * returns the total number of <b>milliseconds </b> spent by the virtual
     * machine performing compilations. The figure is taken over the lifetime of
     * the virtual machine.
     * 
     * @return the compilation time in milliseconds
     * @throws java.lang.UnsupportedOperationException
     *             if the virtual machine does not support compilation
     *             monitoring. This can be tested by calling the
     *             {@link #isCompilationTimeMonitoringSupported()}method.
     */
    public long getTotalCompilationTime();

    /**
     * A boolean indication of whether or not the virtual machine supports the
     * timing of its compilation facilities.
     * 
     * @return <code>true</code> if compilation timing is supported, otherwise
     *         <code>false</code>.
     */
    public boolean isCompilationTimeMonitoringSupported();

}


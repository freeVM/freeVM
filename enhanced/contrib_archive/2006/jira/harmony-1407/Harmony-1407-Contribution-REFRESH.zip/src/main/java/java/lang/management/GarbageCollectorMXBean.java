/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * 
 */

package java.lang.management;

/**
 * The interface for managing and monitoring the virtual machine's garbage
 * collection functionality.
 * <p>
 * Multiple instances of this interface are available to clients. Each may be
 * distinguished by their separate <code>ObjectName</code> value.
 * </p>
 * <p>
 * Accessing this kind of <code>MXBean</code> can be done in one of three
 * ways. <br/>
 * <ol>
 * <li>Invoking the static
 * {@link ManagementFactory#getGarbageCollectorMXBeans()}method which returns a
 * {@link java.util.List}of all currently instantiated GarbageCollectorMXBeans.
 * </li>
 * <li>Using a {@link javax.management.MBeanServerConnection}.</li>
 * <li>Obtaining a proxy MXBean from the static
 * {@link ManagementFactory#newPlatformMXBeanProxy}method, passing in the
 * string &quot;java.lang:type=GarbageCollector,name= <i>unique collector's name
 * </i>&quot; for the value of the second parameter.</li>
 * </ol>
 * </p>
 * 
 * @since 1.5
 */
public interface GarbageCollectorMXBean extends MemoryManagerMXBean {

    /**
     * Returns in a long the number of garbage collections carried out by the
     * associated collector.
     * 
     * @return the total number of garbage collections that have been carried
     *         out by the associated garbage collector.
     */
    public long getCollectionCount();

    /**
     * For the associated garbage collector, returns the total amount of time in
     * milliseconds that it has spent carrying out garbage collection.
     * 
     * @return the number of milliseconds that have been spent in performing
     *         garbage collection. This is a cumulative figure.
     */
    public long getCollectionTime();

}


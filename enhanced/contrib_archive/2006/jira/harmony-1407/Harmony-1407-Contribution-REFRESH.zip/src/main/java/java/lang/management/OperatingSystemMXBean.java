/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 * 
 */

package java.lang.management;

/**
 * The management and monitoring interface for the operating system where the
 * virtual machine is running.
 * <p>
 * Precisely one instance of this interface will be made available to management
 * clients.
 * </p>
 * <p>
 * Accessing this <code>MXBean</code> can be done in one of three ways. <br/>
 * <ol>
 * <li>Invoking the static ManagementFactory.getOperatingSystemMXBean() method.
 * </li>
 * <li>Using a javax.management.MBeanServerConnection.</li>
 * <li>Obtaining a proxy MXBean from the static
 * {@link ManagementFactory#newPlatformMXBeanProxy}method, passing in
 * &quot;java.lang:type=OperatingSystem&quot; for the value of the second
 * parameter.</li>
 * </ol>
 * </p>
 * 
 * @since 1.5
 */
public interface OperatingSystemMXBean {

    /**
     * Returns a unique string identifier for the architecture of the underlying
     * operating system. The identifier value is identical to that which would
     * be obtained from a call to {@link System#getProperty(java.lang.String)}
     * supplying the value &quot;os.arch&quot; for the key.
     * 
     * @return the identifier for the operating system architecture.
     * @throws SecurityException
     *             if there is a security manager in operation and the caller
     *             does not have permission to check system properties.
     * @see System#getProperty(java.lang.String)
     */
    public String getArch();

    /**
     * Returns the number of processors that are available for the virtual
     * machine to run on. The information returned from this method is identical
     * to that which would be received from a call to
     * {@link Runtime#availableProcessors()}.
     * 
     * @return the number of available processors.
     */
    public int getAvailableProcessors();

    /**
     * Returns the name of the underlying operating system. The value is
     * identical to that which would be obtained from a call to
     * {@link System#getProperty(java.lang.String)}supplying the value
     * &quot;os.name&quot; for the key.
     * 
     * @return the name of the operating system.
     * @throws SecurityException
     *             if there is a security manager in operation and the caller
     *             does not have permission to check system properties.
     * @see System#getProperty(java.lang.String)
     */
    public String getName();

    /**
     * Returns the version string for the underlying operating system. The value
     * is identical to that which would be obtained from a call to
     * {@link System#getProperty(java.lang.String)}supplying the value
     * &quot;os.version&quot; for the key.
     * 
     * @return the version of the operating system.
     * @throws SecurityException
     *             if there is a security manager in operation and the caller
     *             does not have permission to check system properties.
     * @see System#getProperty(java.lang.String)
     */
    public String getVersion();

}

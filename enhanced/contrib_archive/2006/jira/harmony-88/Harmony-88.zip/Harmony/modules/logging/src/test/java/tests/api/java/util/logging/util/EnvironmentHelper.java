/* Copyright 2004 The Apache Software Foundation or its licensors, as applicable
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tests.api.java.util.logging.util;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Properties;

/**
 * Helper to prepare testing environment, for example, configuration files.
 */
public class EnvironmentHelper {

	/**
	 * Can't be instantiated.
	 */
	private EnvironmentHelper() {
	}

	public static InputStream PropertiesToInputStream(Properties p) {
		ByteArrayOutputStream bos = null;
		try {
			bos = new ByteArrayOutputStream();
			p.store(bos, "");
			return new ByteArrayInputStream(bos.toByteArray());
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				bos.close();
			} catch (Exception ex) {
			}
		}
	}

}

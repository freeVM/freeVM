/* Copyright 2004 The Apache Software Foundation or its licensors, as applicable
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tests.api.java.util.logging;

import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;

import junit.framework.TestCase;
import tests.util.SerializationTester;

/**
 * 
 */
public class LogRecordTest extends TestCase {

	static final String MSG = "test msg, pls. ignore itb";

	private LogRecord lr;

	private static String className = LogRecordTest.class.getName();

	/*
	 * @see TestCase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		lr = new LogRecord(Level.CONFIG, MSG);

	}

	/*
	 * @see TestCase#tearDown()
	 */
	protected void tearDown() throws Exception {
		super.tearDown();
	}

	/**
	 * Constructor for LogRecordTest.
	 * 
	 * @param arg0
	 */
	public LogRecordTest(String arg0) {
		super(arg0);
	}

	public void testLogRecordWithNullPointers() {
		try {
			LogRecord r = new LogRecord(null, null);
			fail("should throw NullPointerException");
		} catch (NullPointerException e) {
		}
		try {
			LogRecord r = new LogRecord(null, MSG);
			fail("should throw NullPointerException");
		} catch (NullPointerException e) {
		}
		LogRecord r = new LogRecord(Level.WARNING, null);
		assertSame(r.getLevel(), Level.WARNING);
		assertNull(r.getMessage());
	}

	public void testGetSetLoggerName() {
		assertNull(lr.getLoggerName());
		lr.setLoggerName(null);
		assertNull(lr.getLoggerName());
		lr.setLoggerName("test logger name");
		assertEquals("test logger name", lr.getLoggerName());
	}

	public void testGetSetResourceBundle() {
		assertNull(lr.getResourceBundleName());
		assertNull(lr.getResourceBundle());

		lr.setResourceBundle(null);
		assertNull(lr.getResourceBundle());

		lr.setResourceBundleName("tests/api/java/util/logging/res");
		assertNull(lr.getResourceBundle());

		lr.setResourceBundleName(null);
		ResourceBundle rb = ResourceBundle
				.getBundle("tests/api/java/util/logging/res");
		lr.setResourceBundle(rb);
		assertEquals(rb, lr.getResourceBundle());
		assertNull(lr.getResourceBundleName());
	}

	public void testGetSetResourceBundleName() {
		assertNull(lr.getResourceBundleName());
		lr.setResourceBundleName(null);
		assertNull(lr.getResourceBundleName());
		lr.setResourceBundleName("test");
		assertEquals("test", lr.getResourceBundleName());
	}

	public void testGetSetLevel() {
		try {
			lr.setLevel(null);
			fail("should throw NullPointerException");
		} catch (NullPointerException e) {
		}
		assertSame(lr.getLevel(), Level.CONFIG);
	}

	public void testGetSetSequenceNumber() {
		long l = lr.getSequenceNumber();
		lr.setSequenceNumber(-111);
		assertEquals(lr.getSequenceNumber(), -111L);
		lr.setSequenceNumber(0);
		assertEquals(lr.getSequenceNumber(), 0L);
		lr = new LogRecord(Level.ALL, null);
		assertEquals(lr.getSequenceNumber(), l + 1);
	}

	public void testGetSetSourceClassName() {
		lr.setSourceClassName(null);
		assertNull(lr.getSourceClassName());
		lr.setSourceClassName("bad class name");
		assertEquals("bad class name", lr.getSourceClassName());
		lr.setSourceClassName(this.getClass().getName());
		assertEquals(this.getClass().getName(), lr.getSourceClassName());
	}

	public void testGetSetSourceMethodName() {
		lr.setSourceMethodName(null);
		assertNull(lr.getSourceMethodName());
		lr.setSourceMethodName("bad class name");
		assertEquals("bad class name", lr.getSourceMethodName());
		lr.setSourceMethodName(this.getClass().getName());
		assertEquals(this.getClass().getName(), lr.getSourceMethodName());
	}

	public void testGetSourceDefaultValue() {
		assertNull(lr.getSourceMethodName());
		assertNull(lr.getSourceClassName());

		// find class and method who called logger
		Logger logger = Logger.global;
		MockHandler handler = new MockHandler();
		logger.addHandler(handler);
		logger.log(Level.SEVERE, MSG);
		assertEquals(this.getClass().getName(), handler.getSourceClassName());
		assertEquals("testGetSourceDefaultValue", handler.getSourceMethodName());

		// only set source method to null
		lr = new LogRecord(Level.SEVERE, MSG);
		lr.setSourceMethodName(null);
		logger.log(lr);
		assertEquals(null, handler.getSourceClassName());
		assertEquals(null, handler.getSourceMethodName());

		// only set source class to null
		lr = new LogRecord(Level.SEVERE, MSG);
		lr.setSourceClassName(null);
		logger.log(lr);
		assertEquals(null, handler.getSourceClassName());
		assertEquals(null, handler.getSourceMethodName());

		// set both
		lr = new LogRecord(Level.SEVERE, MSG);
		lr.setSourceClassName("className");
		lr.setSourceMethodName(null);
		logger.log(lr);
		assertEquals("className", handler.getSourceClassName());
		assertEquals(null, handler.getSourceMethodName());

		// test if LogRecord is constructed in another class, and is published
		// by Logger
		logger.log(RecordFactory.getDefaultRecord());
		assertEquals(this.getClass().getName(), handler.getSourceClassName());
		assertEquals("testGetSourceDefaultValue", handler.getSourceMethodName());

		lr = RecordFactory.getDefaultRecord();
		// assertNull(lr.getSourceClassName());
		// assertNull(lr.getSourceMethodName());
		RecordFactory.log(logger, lr);
		assertEquals(RecordFactory.class.getName(), handler
				.getSourceClassName());
		assertEquals("log", handler.getSourceMethodName());

		// only try once to get the default value
		lr = RecordFactory.getDefaultRecord();
		assertNull(lr.getSourceClassName());
		assertNull(lr.getSourceMethodName());
		RecordFactory.log(logger, lr);
		assertNull(handler.getSourceClassName());
		assertNull(handler.getSourceMethodName());

		// it cannot find correct default value when logger is subclass
		MockLogger ml = new MockLogger("foo", null);
		ml.addHandler(handler);
		ml.info(MSG);
		assertEquals(className + "$MockLogger", handler.getSourceClassName());
		assertEquals("info", handler.getSourceMethodName());

		// it can find nothing when only call Subclass
		ml = new MockLogger("foo", null);
		ml.addHandler(handler);
		ml.log(Level.SEVERE, MSG);
		assertNull(handler.getSourceClassName());
		assertNull(handler.getSourceMethodName());

		// test if don't call logger, what is the default value
		lr = new LogRecord(Level.SEVERE, MSG);
		handler.publish(lr);
		assertNull(handler.getSourceClassName());
		assertNull(handler.getSourceMethodName());
		logger.removeHandler(handler);
	}

	public void testGetSetMessage() {
		assertEquals(MSG, lr.getMessage());
		lr.setMessage(null);
		assertNull(lr.getMessage());
		lr.setMessage("");
		assertEquals("", lr.getMessage());
	}

	public void testGetSetParameters() {
		assertNull(lr.getParameters());
		lr.setParameters(null);
		assertNull(lr.getParameters());
		Object[] oa = new Object[0];
		lr.setParameters(oa);
		assertEquals(oa, lr.getParameters());
		oa = new Object[] { new Object(), new Object() };
		lr.setParameters(oa);
		assertSame(oa, lr.getParameters());
	}

	public void testGetSetMillis() {
		long milli = lr.getMillis();
		lr.setMillis(-1);
		assertEquals(-1, lr.getMillis());
		lr.setMillis(0);
		assertEquals(0, lr.getMillis());
	}

	public void testGetSetThreadID() {
		// TODO how to test the different thread
		int id = lr.getThreadID();
		lr = new LogRecord(Level.ALL, "a1");
		assertEquals(id, lr.getThreadID());
		lr.setThreadID(id + 10);
		assertEquals(id + 10, lr.getThreadID());
		lr = new LogRecord(Level.ALL, "a1");
		assertEquals(id, lr.getThreadID());
	}

	public void testGetSetThrown() {
		assertNull(lr.getThrown());
		lr.setThrown(null);
		assertNull(lr.getThrown());
		Throwable e = new Exception();
		lr.setThrown(e);
		assertEquals(e, lr.getThrown());
	}

	public void testSerialization() throws Exception {
		lr.setLoggerName("logger");
		lr.setResourceBundleName("tests/api/java/util/logging/res2");
		lr.setSourceClassName("class");
		lr.setSourceMethodName("method");
		lr.setParameters(new Object[] { new Object(), new Object() });
		lr.setThreadID(1000);
		lr.setThrown(new Exception("exception"));
		lr.setSequenceNumber(12321312);
		lr.setMillis(12313123);
		lr.setResourceBundle(ResourceBundle.getBundle(
				"tests/api/java/util/logging/res", Locale.US));
		if (!SerializationTester.assertEquals(lr)) {
			LogRecord result = (LogRecord) SerializationTester.getLastOutput();
			assertSame(result.getLevel(), lr.getLevel());
			assertEquals(result.getLoggerName(), lr.getLoggerName());
			assertEquals(result.getMessage(), lr.getMessage());
			assertEquals(result.getResourceBundleName(), lr
					.getResourceBundleName());
			assertEquals(result.getSourceClassName(), lr.getSourceClassName());
			assertEquals(result.getSourceMethodName(), lr.getSourceMethodName());
			assertEquals(result.getMillis(), lr.getMillis());
			Object[] oa = result.getParameters();
			Object[] ob = lr.getParameters();
			for (int i = 0; i < oa.length; i++) {
				assertEquals(oa[i].toString(), ob[i].toString());
			}
			assertNotNull(result.getResourceBundle());
			assertFalse(result.getResourceBundle().equals(
					lr.getResourceBundle()));
			assertEquals(result.getThreadID(), lr.getThreadID());
			assertEquals(result.getThrown().getMessage(), lr.getThrown()
					.getMessage());
			assertEquals(result.getSequenceNumber(), lr.getSequenceNumber());

		}
	}

	public void testSerializationInvalidBundleName() throws Exception {
		lr.setLoggerName("logger");
		lr.setResourceBundleName("bad bundle name");
		lr.setSourceClassName("class");
		lr.setSourceMethodName("method");
		lr.setParameters(new Object[] { new Object(), new Object() });
		lr.setThreadID(1000);
		lr.setThrown(new Exception("exception"));
		lr.setSequenceNumber(12321312);
		lr.setMillis(12313123);
		lr.setResourceBundle(ResourceBundle.getBundle(
				"tests/api/java/util/logging/res", Locale.US));
		if (!SerializationTester.assertEquals(lr)) {
			LogRecord result = (LogRecord) SerializationTester.getLastOutput();
			assertSame(result.getLevel(), lr.getLevel());
			assertEquals(result.getLoggerName(), lr.getLoggerName());
			assertEquals(result.getMessage(), lr.getMessage());
			assertEquals(result.getResourceBundleName(), lr
					.getResourceBundleName());
			assertEquals(result.getSourceClassName(), lr.getSourceClassName());
			assertEquals(result.getSourceMethodName(), lr.getSourceMethodName());
			assertEquals(result.getMillis(), lr.getMillis());
			Object[] oa = result.getParameters();
			Object[] ob = lr.getParameters();
			for (int i = 0; i < oa.length; i++) {
				assertEquals(oa[i].toString(), ob[i].toString());
			}
			assertNull(result.getResourceBundle());
			assertEquals(result.getThreadID(), lr.getThreadID());
			assertEquals(result.getThrown().getMessage(), lr.getThrown()
					.getMessage());
			assertEquals(result.getSequenceNumber(), lr.getSequenceNumber());

		}
	}

	public void testSerializationCompability() throws Exception {
		LogRecord r = new LogRecord(Level.ALL, "msg");
		SerializationTester.assertCompabilityEquals(r,
				"tests/api/java/util/logging/LogRecord.ser");
	}

	public static class MockHandler extends Handler {
		private String className;

		private String methodName;

		public void close() {
		}

		public void flush() {
		}

		public void publish(LogRecord record) {
			className = record.getSourceClassName();
			methodName = record.getSourceMethodName();
		}

		public String getSourceMethodName() {
			return methodName;
		}

		public String getSourceClassName() {
			return className;
		}
	}

	// mock class, try to test when the sourceclass and sourcemethod of
	// LogRecord is inited
	public static class RecordFactory {

		public static LogRecord getDefaultRecord() {
			return new LogRecord(Level.SEVERE, MSG);
		}

		public static void log(Logger logger, LogRecord lr) {
			logger.log(lr);
		}
	}

	public static class MockLogger extends Logger {

		/**
		 * @param name
		 * @param resourceBundleName
		 */
		public MockLogger(String name, String resourceBundleName) {
			super(name, resourceBundleName);
		}

		public void log(Level l, String s) {
			this.log(new LogRecord(l, s));
		}

		public void info(String s) {
			super.info(s);
		}

		public void log(LogRecord record) {
			if (isLoggable(record.getLevel())) {
				// call the handlers of this logger
				// TODO: What if an exception occured in handler?
				Handler[] ha = this.getHandlers();
				for (int i = 0; i < ha.length; i++) {
					ha[i].publish(record);
				}
				// call the parent's handlers if set useParentHandlers
				if (getUseParentHandlers()) {
					Logger anyParent = this.getParent();
					while (null != anyParent) {
						ha = anyParent.getHandlers();
						for (int i = 0; i < ha.length; i++) {
							ha[i].publish(record);
						}
						if (anyParent.getUseParentHandlers()) {
							anyParent = anyParent.getParent();
						} else {
							break;
						}
					}
				}
			}
		}
	}
}

/* Copyright 2005 The Apache Software Foundation or its licensors, as applicable
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tests.api.java.security;

import junit.framework.Test;
import junit.framework.TestSuite;

/**
 * Suite that includes all tests for package java.security
 */
public class AllTests {

	public static Test suite() {
		TestSuite suite = new TestSuite("Tests for java.security");
		// $JUnit-BEGIN$
		suite.addTestSuite(AccessControlContextTest.class);
		suite.addTestSuite(AccessControlExceptionTest.class);
		suite.addTestSuite(AccessControllerTest.class);
		suite.addTestSuite(AlgorithmParameterGeneratorTest.class);
		suite.addTestSuite(AlgorithmParametersTest.class);
		suite.addTestSuite(AllPermissionTest.class);
		suite.addTestSuite(BasicPermissionTest.class);
		suite.addTestSuite(CodeSourceTest.class);
		suite.addTestSuite(DigestExceptionTest.class);
		suite.addTestSuite(DigestInputStreamTest.class);
		suite.addTestSuite(DigestOutputStreamTest.class);
		suite.addTestSuite(DomainCombinerTest.class);
		suite.addTestSuite(GeneralSecurityExceptionTest.class);
		suite.addTestSuite(IdentityTest.class);
		suite.addTestSuite(IdentityScopeTest.class);
		suite.addTestSuite(InvalidAlgorithmParameterExceptionTest.class);
		suite.addTestSuite(InvalidKeyExceptionTest.class);
		suite.addTestSuite(InvalidParameterExceptionTest.class);
		suite.addTestSuite(KeyExceptionTest.class);
		suite.addTestSuite(KeyFactoryTest.class);
		suite.addTestSuite(KeyManagementExceptionTest.class);
		suite.addTestSuite(KeyPairGeneratorTest.class);
		suite.addTestSuite(KeyStoreTest.class);
		suite.addTestSuite(KeyStoreExceptionTest.class);
		suite.addTestSuite(MessageDigestTest.class);
		suite.addTestSuite(NoSuchAlgorithmExceptionTest.class);
		suite.addTestSuite(NoSuchProviderExceptionTest.class);
		suite.addTestSuite(PermissionTest.class);
		suite.addTestSuite(PermissionCollectionTest.class);
		suite.addTestSuite(PermissionsTest.class);
		suite.addTestSuite(PolicyTest.class);
		suite.addTestSuite(PrincipalTest.class);
		suite.addTestSuite(PrivilegedActionExceptionTest.class);
		suite.addTestSuite(ProviderTest.class);
		suite.addTestSuite(ProviderExceptionTest.class);
		suite.addTestSuite(SecureClassLoaderTest.class);
		suite.addTestSuite(SecureRandomTest.class);
		suite.addTestSuite(SecurityTest.class);
		suite.addTestSuite(SecurityPermissionTest.class);
		suite.addTestSuite(SignatureTest.class);
		suite.addTestSuite(SignatureExceptionTest.class);
		suite.addTestSuite(SignerTest.class);
		suite.addTestSuite(UnrecoverableKeyExceptionTest.class);
		// $JUnit-END$
		return suite;
	}
}

/* Copyright 2004 The Apache Software Foundation or its licensors, as applicable
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tests.main;

import junit.extensions.TestSetup;
import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestSuite;

public class AllTests {

	public static void main(String[] args) {
		junit.textui.TestRunner.run(AllTests.suite());
	}

	public static Test suite() {
		TestSuite suite = new TestSuite("All test suites");
		// $JUnit-BEGIN$
		
		// Needs beans implementation in trunk
		// suite.addTest(tests.beans.AllTests.suite());
		
		// Needs crypto implementation in trunk
		// suite.addTest(tests.crypto.AllTests.suite());
		
		// Needs applet implementation in trunk
		// suite.addTest(tests.jndi.AllTests.suite());
		
		// Needs beans implementation in trunk
		// suite.addTest(tests.logging.AllTests.suite());

		// Needs rmi implementation in trunk
		// suite.addTest(tests.sql.AllTests.suite());
		
		suite.addTest(tests.math.AllTests.suite());
		suite.addTest(tests.prefs.AllTests.suite());
		suite.addTest(tests.regex.AllTests.suite());
		suite.addTest(tests.security.AllTests.suite());
		// $JUnit-END$

		return suite;
	}
}

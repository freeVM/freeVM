/* Copyright 1998, 2005 The Apache Software Foundation or its licensors, as applicable
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *     http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package tests.api.java.util;

import java.util.AbstractMap;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.WeakHashMap;

public class AbstractMapTest extends junit.framework.TestCase {

	static final String specialKey = "specialKey".intern();

	static final String specialValue = "specialValue".intern();

	// The impl of MyMap is not realistic, but serves to create a type
	// that uses the default remove behavior.
	class MyMap extends AbstractMap {
		final Set mySet = new HashSet(1);

		MyMap() {
			mySet.add(new Map.Entry() {
				public Object getKey() {
					return specialKey;
				}

				public Object getValue() {
					return specialValue;
				}

				public Object setValue(Object object) {
					return null;
				}
			});
		}

		public Object put(Object key, Object value) {
			return null;
		}

		public Set entrySet() {
			return mySet;
		}
	}

	/**
	 * @tests java.util.AbstractMap#keySet()
	 */
	public void test_keySet() {
		AbstractMap map1 = new HashMap(0);
		assertSame("HashMap(0)", map1.keySet(), map1.keySet());

		AbstractMap map2 = new HashMap(10);
		assertSame("HashMap(10)", map2.keySet(), map2.keySet());

		Map map3 = Collections.EMPTY_MAP;
		assertSame("EMPTY_MAP", map3.keySet(), map3.keySet());

		AbstractMap map4 = new IdentityHashMap(1);
		assertSame("IdentityHashMap", map4.keySet(), map4.keySet());

		AbstractMap map5 = new LinkedHashMap(122);
		assertSame("LinkedHashMap", map5.keySet(), map5.keySet());

		AbstractMap map6 = new TreeMap();
		assertSame("TreeMap", map6.keySet(), map6.keySet());

		AbstractMap map7 = new WeakHashMap();
		assertSame("WeakHashMap", map7.keySet(), map7.keySet());
	}

	/**
	 * @tests java.util.AbstractMap#remove(java.lang.Object)
	 */
	public void test_removeLjava_lang_Object() {
		Object key = new Object();
		Object value = new Object();

		AbstractMap map1 = new HashMap(0);
		map1.put("key", value);
		assertSame("HashMap(0)", map1.remove("key"), value);

		AbstractMap map4 = new IdentityHashMap(1);
		map4.put(key, value);
		assertSame("IdentityHashMap", map4.remove(key), value);

		AbstractMap map5 = new LinkedHashMap(122);
		map5.put(key, value);
		assertSame("LinkedHashMap", map5.remove(key), value);

		AbstractMap map6 = new TreeMap(new Comparator() {
			// Bogus comparator
			public int compare(Object object1, Object object2) {
				return 0;
			}
		});
		map6.put(key, value);
		assertSame("TreeMap", map6.remove(key), value);

		AbstractMap map7 = new WeakHashMap();
		map7.put(key, value);
		assertSame("WeakHashMap", map7.remove(key), value);

		AbstractMap aSpecialMap = new MyMap();
		aSpecialMap.put(specialKey, specialValue);
		Object valueOut = aSpecialMap.remove(specialKey);
		assertSame("MyMap", valueOut, specialValue);
	}

	/**
	 * @tests java.util.AbstractMap#values()
	 */
	public void test_values() {
		AbstractMap map1 = new HashMap(0);
		assertSame("HashMap(0)", map1.values(), map1.values());

		AbstractMap map2 = new HashMap(10);
		assertSame("HashMap(10)", map2.values(), map2.values());

		Map map3 = Collections.EMPTY_MAP;
		assertSame("EMPTY_MAP", map3.values(), map3.values());

		AbstractMap map4 = new IdentityHashMap(1);
		assertSame("IdentityHashMap", map4.values(), map4.values());

		AbstractMap map5 = new LinkedHashMap(122);
		assertSame("IdentityHashMap", map5.values(), map5.values());

		AbstractMap map6 = new TreeMap();
		assertSame("TreeMap", map6.values(), map6.values());

		AbstractMap map7 = new WeakHashMap();
		assertSame("WeakHashMap", map7.values(), map7.values());
	}

	/**
	 * @tests java.util.AbstractMap#clone()
	 */
	public void test_clone() {
		class MyMap extends AbstractMap implements Cloneable {
			private Map map = new HashMap();

			public Set entrySet() {
				return map.entrySet();
			}

			public Object put(Object key, Object value) {
				return map.put(key, value);
			}

			public Map getMap() {
				return map;
			}

			public Object clone() {
				try {
					return super.clone();
				} catch (CloneNotSupportedException e) {
					return null;
				}
			}
		}
		;
		MyMap map = new MyMap();
		map.put("one", "1");
		Map.Entry entry = (Map.Entry) map.entrySet().iterator().next();
		assertTrue("entry not added", entry.getKey() == "one"
				&& entry.getValue() == "1");
		MyMap mapClone = (MyMap) map.clone();
		assertTrue("clone not shallow", map.getMap() == mapClone.getMap());
	}

	protected void setUp() {
	}

	protected void tearDown() {
	}
}

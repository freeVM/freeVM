README
======



Contents
--------
This directory contains unit tests for the following Harmony components...

* archive
* luni
* nio_char
* text

The contents of this zip have been laid out with the current classlib directory
structure of the Apache Harmony SVN repository in mind. It is assumed that 
prior to using this zip the user has followed the recommended instructions 
at http://incubator.apache.org/harmony/documentation/build_classlib.html for
checking out and building the class libraries from source and will have the
following directory structure in their workspace ...

Harmony
   |
   +---- depends
   |
   |---- doc
   |
   +---- make
   |
   +---- modules
   |
   \---- native-src



This zip also has a top-level directory called "Harmony" and is structured so
that it may be easily unzipped over the above directory layout. This is best 
illustrated with the following overview of the zip directory tree ...

<EXTRACT_DIR>
       |
       \---Harmony
              |
              +---- Harmony_Tests     <- unit test support classes and resources
              |
              +---- make              <- contains updated build-java.xml file
              |
              +---- modules
                      |
                      +---archive     <- unit tests for archive component
                      |
                      +---luni        <- unit tests for luni component
                      |
                      +---nio_char    <- unit tests for nio_char component
                      |
                      \---text        <- unit tests for text component



Each of the modules subdirectories contains a "src/test" folder that holds the
unit test code for that module. 



Building and Running
--------------------
The file <EXTRACT_DIR>/Harmony/make/build-java.xml contained in this archive
comprises the latest version of enhanced/classlib/trunk/make/build-java.xml
in the https://svn.apache.org/repos/asf/incubator/harmony/ repository location
together with a small number of new Ant targets aimed at building and running
the JUnit tests contained in this archive. The new targets comprise of ...

* compile-tests
* copy-test-resources
* clean-test-bin
* run-tests
* get-test-support-jars


The "get-test-support-jars" target is provided as a convenience to download a
small number of jars required to compile and run the unit test cases from the 
repository of jars available at ibiblio.org. This target needs to be run just
the once before attempting to compile and run the unit tests. After this step
has been carried out the "compile-tests" and "run-tests" targets may be run
(in that order) to run all of the module unit tests contained in this zip.



Runtime Configuration
---------------------
In order for the "run-tests" target of <EXTRACT_DIR>/Harmony/make/build-java.xml
to work correctly please ensure that the junit.jar file is available either 
on the system classpath or else in your <ANT_HOME>/lib directory.

In addition to the support jars obtained through the "get-test-support-jars"
described above, a number of test cases for types in the java.net package depend
on some extra resources being deployed. Please refer to the instructions in 
<EXTRACT_DIR>/Harmony/Harmony_Tests/src/test/resources/net.resources/README.txt
for more on this topic. 



SomeTests Decorator
-------------------
The "run-tests" Ant target in <EXTRACT_DIR>/Harmony/make/build-java.xml calls
the class tests.main.AllTests. This test suite creates a new JUnit TestSuite
that contains all of the top level test suites in each of the modules. The 
TestSuite object is then wrapped inside a small decorator class called 
tests.util.SomeTests. The purpose of this class is to filter the test cases that
get run according to a list of preferred test case exclusions that may
optionally be provided by the user. When this decorator is used the set of test
case methods that get run equates to ...

(all modules test cases) - (all method exclusion entries in the excludes file)

The tests.util.SomeTests decorator class locates exclusions files through the
"excludes.file.uri" property. If set, this should contain the the full path to 
the exclusions file used. There is no default value for this property : if not
set the decorator will permit all test case methods to be run.

<EXTRACT_DIR>/Harmony/Harmony_Tests/src/test/resources/config/jcltest-excludes.xml
is an example of an exclusions list file. The file is an XML document that must
conform to the XML schema set out in 
<EXTRACT_DIR>/Harmony/Harmony_Tests/src/test/resources/config/excludes.xsd .

By excluding tests that are known to fail it is possible to build up a central
record of all of the known problems with the body of code under test. When a 
problem gets fixed the associated failing test case(s) can be removed from the
exclusions list. 

To run all the unit tests without any exclusions do not set the
"excludes.file.uri" property at runtime or else update the tests.main.AllTests
class so that its constructed TestSuite is not wrapped in a SomeTests object. 

